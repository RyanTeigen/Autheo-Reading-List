# Marketing

### [Influence: The Psychology of Persuasion](https://www.goodreads.com/book/show/28815.Influence)
**Type:** Book  
**Author:** Robert Cialdini  
**Summary:** Foundation of modern persuasion psychology.
