# Quantum Computing

### [An Introduction to Quantum Computing](https://arxiv.org/abs/quant-ph/0011013)
**Type:** Paper  
**Author:** Phillip Kaye  
**Summary:** A primer on qubits, gates, and quantum algorithms.

### [IBM Quantum Learning Pathways](https://learning.quantum-computing.ibm.com/)
**Type:** Course  
**Author:** IBM  
**Summary:** Hands-on intro to quantum circuits and Qiskit.
