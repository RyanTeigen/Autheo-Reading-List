# Resilience

### [Grit](https://angeladuckworth.com/grit-book/)
**Type:** Book  
**Author:** Angela Duckworth  
**Summary:** Study of long-term resilience.
