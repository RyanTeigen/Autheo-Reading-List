# Lifestyle

### [Atomic Habits](https://jamesclear.com/atomic-habits)
**Type:** Book  
**Author:** James Clear  
**Summary:** Framework for building good habits.
