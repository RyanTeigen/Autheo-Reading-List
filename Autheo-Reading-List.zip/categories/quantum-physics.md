# Quantum Physics

### [The Feynman Lectures on Physics](https://www.feynmanlectures.caltech.edu/)
**Type:** Book  
**Author:** Richard P. Feynman  
**Summary:** Classic introduction to quantum mechanics.
