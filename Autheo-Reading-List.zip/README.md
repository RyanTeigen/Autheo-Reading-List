# 📚 Company Reading List (Open Source)

Welcome to the **Autheo Reading List** — a curated, community-driven collection of articles, whitepapers, books, papers, and long-form resources recommended by team members.

This repository is open source so that anyone in our ecosystem can:
- discover high-quality reading material,
- contribute new resources,
- propose new categories,
- maintain a canonical list of knowledge for the community.

## 📁 Structure
All reading lists live in the `categories/` folder.

## 📥 How to Add a New Resource
1. Fork the repo  
2. Add your resource to an existing category file  
3. Submit a PR

Format:
```markdown
### [Title of Resource](URL)
**Type:** Article | Book | Paper | Video  
**Author:** Name  
**Summary:** 1–3 sentences
```
