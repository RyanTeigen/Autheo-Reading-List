# Contributing Guide

Thanks for helping grow the Reading List!

Use this format:
```markdown
### [Resource Title](URL)
**Type:** Article | Book | Paper | Video  
**Author:**  
**Summary:** Short description
```
